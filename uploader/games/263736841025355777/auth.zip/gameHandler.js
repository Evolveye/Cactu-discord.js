import formidable from "formidable"
import fs  from "fs"

import { getUserFromToken } from "./auth.js"

/**
 * @param {import("http").ClientRequest} req
 * @param {import("http").ServerResponse} res
 * @param {string[]} urlParts
 */
export default function handlerGames( req, res, urlParts ) {
  if (req.method.toLowerCase() != `post`) return

  /** @type {formidable.IncomingForm} */
  const form = formidable({ multiplies:true })

  form.parse( req, (err, fields, files) => {
    const tempPath = files.game.path
    const raw = fs.readFileSync( tempPath )
    const { user } = getUserFromToken( fields.token )

    fs.writeFile( `./games/${user.id}` )

    console.log( { fields, files } )
  } )
}