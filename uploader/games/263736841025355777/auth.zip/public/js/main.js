import "./authorize.js"
import "./uploadGame.js"