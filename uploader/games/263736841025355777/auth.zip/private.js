export default {
  clientId: `379234773408677888`,
  clientSecret: `tzw9NXGwRax4qPpixzxBGJsJXsDbHPFo`,
}